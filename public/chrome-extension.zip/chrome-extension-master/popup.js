document.addEventListener('DOMContentLoaded', () => {
  const getCookieButton = document.getElementById('get-cookie');
  const emailInput = document.getElementById('email-input'); // Get the input field
  const statusMessage = document.getElementById('status-message'); // Element to display the status message

  if (getCookieButton) {
      getCookieButton.addEventListener('click', async () => {
          const email = emailInput.value; // Get the email value
          const linkedinCookie = await getLinkedInCookie(); // Get the LinkedIn cookie

          // Prepare the data to send
          const requestData = {
              user_id: email,
              linkedin_token: linkedinCookie // Include the LinkedIn cookie in the request
          };

          try {
              const response = await fetch('https://backtest.agentprod.com/v2/linkedin/login', { // Adjust the URL as necessary
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/json',
                  },
                  body: JSON.stringify(requestData),
              });

              if (response.status === 200) {
                  // Successful connection
                  statusMessage.textContent = 'Connection successful!';
                  statusMessage.style.color = 'green'; // Set the text color to green
              } else {
                  // Connection failed
                  statusMessage.textContent = 'Connection not successful.';
                  statusMessage.style.color = 'red'; // Set the text color to red
              }
          } catch (error) {
              // Handle network errors
              statusMessage.textContent = 'An error occurred. Please try again.';
              statusMessage.style.color = 'red'; // Set the text color to red
          }
      });
  } else {
      console.error("Button with ID 'get-cookie' not found.");
  }
});

// Function to retrieve the LinkedIn cookie
async function getLinkedInCookie() {
  return new Promise((resolve, reject) => {
      chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'li_at' }, (cookie) => {
          if (chrome.runtime.lastError || !cookie) {
              reject('Cookie not found');
          } else {
              resolve(cookie.value); // Return the cookie value
          }
      });
  });
}
