chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === 'get_li_at_cookie') {
    chrome.cookies.get({ url: "https://www.linkedin.com", name: "li_at" }, (cookie) => {
      if (cookie) {
        sendResponse({ value: cookie.value });
      } else {
        sendResponse({ value: null });
      }
    });
    return true;
  }
});
